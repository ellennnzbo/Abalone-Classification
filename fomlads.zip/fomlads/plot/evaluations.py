import numpy as np
import matplotlib.pyplot as plt

def plot_train_test_errors(
        control_var, experiment_sequence, train_errors, test_errors,
        train_stes=None, test_stes=None):
    """
    Plot the train and test errors for a sequence of experiments.

    parameters
    ----------
    control_var - the name of the control variable, e.g. degree (for polynomial)
        degree.
    experiment_sequence - a list of values applied to the control variable.
    """
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    train_line, = ax.plot(experiment_sequence, train_errors,'b-')
    test_line, = ax.plot(experiment_sequence, test_errors, 'r-')

    if not train_stes is None:
        train_upper = train_errors + train_stes
        train_lower = train_errors - train_stes
        ax.fill_between(
            experiment_sequence,train_lower,train_upper, color='b', alpha=0.2)
    if not test_stes is None:
        test_upper = test_errors + test_stes
        test_lower = test_errors - test_stes
        ax.fill_between(
            experiment_sequence,test_lower,test_upper, color='r', alpha=0.2)

    ax.set_xlabel(control_var)
    ax.set_ylabel("Misclassification Error")
    ax.legend([train_line, test_line], ["train", "test"])
    return fig, ax

def plot_misclassification_errors(
        control_var, experiment_sequence, errors, colour=None, fig_ax=None):
    if fig_ax is None:
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
    else:
        fig, ax = fig_ax
    if colour is None:
        colour='r'
    ax.plot(experiment_sequence, errors, colour)
    ax.set_xlabel(control_var)
    ax.set_ylabel("Misclassification Error")
    return fig, ax

def plot_expected_loss(
        control_var, experiment_sequence, loss, colour=None, fig_ax=None):
    if fig_ax is None:
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
    else:
        fig, ax = fig_ax
    if colour is None:
        colour='r'
    ax.plot(experiment_sequence, loss, colour, linestyle='dashed')
    ax.set_xlabel(control_var)
    return fig, ax

def plot_misclassification_error_and_expected_loss(control_var, experiment_sequence, errors, loss, fig_ax=None, colour=None):
    if fig_ax is None:
        fig, ax0 = plt.subplots()
        ax0.set_xlabel(control_var)
        ax0.set_ylabel('Misclassification Error')
        ax0.plot(experiment_sequence, errors, color=colour)
        ax1 = ax0.twinx()
        ax1.set_ylabel('Expected Loss')
        ax1.plot(experiment_sequence, loss, color=colour, linestyle='dashed')
    else:
        fig, ax0, ax1 = fig_ax
        ax0.plot(experiment_sequence, errors, color=colour)
        ax1.plot(experiment_sequence, loss, color=colour, linestyle='dashed')
    fig.tight_layout()
    return fig, ax0, ax1

def plot_expected_loss(
        control_var, experiment_sequence, train_losses, test_losses,
        train_stes=None, test_stes=None):
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    train_line, = ax.plot(experiment_sequence, train_losses, 'b-')
    test_line, = ax.plot(experiment_sequence, test_losses, 'r-')

    if not train_stes is None:
        train_upper = train_losses + train_stes
        train_lower = train_losses - train_stes
        ax.fill_between(
            experiment_sequence, train_lower, train_upper, color='b', alpha=0.2)
    if not test_stes is None:
        test_upper = test_losses + test_stes
        test_lower = test_losses - test_stes
        ax.fill_between(
            experiment_sequence, test_lower, test_upper, color='r', alpha=0.2)
    ax.set_xlabel(control_var)
    ax.set_ylabel("Expected Loss")
    ax.legend([train_line, test_line], ["train", "test"])
    return fig, ax

def plot_roc(
        false_positive_rates, true_positive_rates, linewidth=3, fig_ax=None,
        colour=None, ofname=None):
    if fig_ax is None:
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
    else:
        fig, ax = fig_ax
    if colour is None:
        colour='r'
    ax.plot(
        false_positive_rates, true_positive_rates, '-', linewidth=linewidth,
        color=colour)
    ax.set_title("ROC Curve")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_aspect('equal', 'box')
    ax.set_xlim([-0.01,1.01])
    ax.set_ylim([-0.01,1.01])
    ax.set_xticks([0,0.5,1])
    ax.set_yticks([0,0.5,1])
    plt.tight_layout()
    if not ofname is None:
        print("Saving ROC curve as: %s" % ofname)
        fig.savefig(ofname)
    return fig, ax

def plot_prc(
        recall, precision, linewidth=3, fig_ax=None,
        colour=None, ofname=None):
    if fig_ax is None:
        fig = plt.figure()
        ax = fig.add_subplot(1,1,1)
    else:
        fig, ax = fig_ax
    if colour is None:
        colour='r'
    ax.plot(
        recall, precision, '-', linewidth=linewidth,
        color=colour)
    ax.set_title("Precision-Recall Curve")
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_aspect('equal', 'box')
    ax.set_xlim([-0.01,1.01])
    ax.set_ylim([-0.01,1.01])
    ax.set_xticks([0,0.5,1])
    ax.set_yticks([0,0.5,1])
    plt.tight_layout()
    if not ofname is None:
        print("Saving PRC curve as: %s" % ofname)
        fig.savefig(ofname)
    return fig, ax

